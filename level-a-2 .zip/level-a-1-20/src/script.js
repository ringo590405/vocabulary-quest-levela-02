document.addEventListener("DOMContentLoaded", function () {
  // ====== DATA ======
  var words = [
  { word: "accept", def: "to say yes to; to receive willingly", zhExplain: "accept＝接受（同意、收下）。易混：except＝除了…（介系詞/連接詞）。", confusable: "except" },
  { word: "accident", def: "an unexpected event that causes harm or damage", zhExplain: "accident＝意外/事故。常用：traffic accident（車禍）。", confusable: "incident" },
  { word: "achieve", def: "to succeed in doing something after trying", zhExplain: "achieve＝達成（目標）。常搭配：achieve a goal / success。", confusable: "complete" },
  { word: "actually", def: "in fact; really", zhExplain: "actually＝其實/事實上（用來修正誤會）。例：Actually, I don’t know. ", confusable: "really" },
  { word: "adult", def: "a fully grown person", zhExplain: "adult＝成人。相對：child。也可作形容詞：adult life。", confusable: "grown-up" },
  { word: "advice", def: "a suggestion about what you should do", zhExplain: "advice＝建議（名詞不可數）。動詞：advise sb to V。", confusable: "suggestion" },
  { word: "advise", def: "to tell someone what you think they should do", zhExplain: "advise＝建議（動詞）。用法：advise sb to + V。", confusable: "suggest" },
  { word: "afford", def: "to have enough money or time for something", zhExplain: "afford＝負擔得起（金錢/時間）。例：I can’t afford it. ", confusable: "pay" },
  { word: "against", def: "opposed to; not in favor of", zhExplain: "against＝反對/對抗。例：be against the plan（反對計畫）。", confusable: "for" },
  { word: "ahead", def: "in front; before; earlier", zhExplain: "ahead＝在前面/提前。例：plan ahead（提前規劃）。", confusable: "beforehand" },

  { word: "alive", def: "living; not dead", zhExplain: "alive＝活著的（表狀態）。living＝活的（可修飾名詞）。", confusable: "living" },
  { word: "alone", def: "without anyone else", zhExplain: "alone＝獨自一人（客觀狀態）。lonely＝孤單（情緒）。", confusable: "lonely" },
  { word: "among", def: "in the middle of; surrounded by", zhExplain: "among＝在…之中（3者以上）。between＝兩者之間。", confusable: "between" },
  { word: "amount", def: "the quantity of something", zhExplain: "amount＝數量（不可數名詞用）。number＝數量（可數名詞用）。", confusable: "number" },
  { word: "announce", def: "to make something known publicly", zhExplain: "announce＝宣布/公告。例：announce the winner。", confusable: "declare" },
  { word: "anyway", def: "in spite of that; used to change topic", zhExplain: "anyway＝反正/總之（轉話題常用）。例：Anyway, let’s start. ", confusable: "however" },
  { word: "apply", def: "to make a request; to use", zhExplain: "apply＝申請/應用。apply for（申請）、apply to（適用於）。", confusable: "use" },
  { word: "appoint", def: "to choose someone for a job or position", zhExplain: "appoint＝指派/任命。例：appoint a new manager。", confusable: "assign" },
  { word: "appreciate", def: "to be thankful for; to value", zhExplain: "appreciate＝感謝/欣賞重視。常用：I appreciate your help. ", confusable: "thank" },
  { word: "argue", def: "to speak angrily because of disagreement", zhExplain: "argue＝爭吵/爭論。常用：argue with sb（和某人吵）。", confusable: "debate" }
];


  var STAGE_SIZE = 10;
  var REVIEW_LIMIT = 5;

  // ====== GET ELEMENTS ======
  var startBtn = document.getElementById("startBtn");
  var game = document.getElementById("game");
  var wordEl = document.getElementById("word");
  var defEl = document.getElementById("definition");
  var choicesEl = document.getElementById("choices");
  var feedback = document.getElementById("feedback");
  var nextBtn = document.getElementById("nextBtn");
  var progressBar = document.getElementById("progress");

  // ====== CHECK REQUIRED ======
  var missing = [];
  if (!startBtn) missing.push("startBtn");
  if (!game) missing.push("game");
  if (!wordEl) missing.push("word");
  if (!defEl) missing.push("definition");
  if (!choicesEl) missing.push("choices");
  if (!feedback) missing.push("feedback");
  if (!nextBtn) missing.push("nextBtn");

  if (missing.length > 0) {
    document.body.innerHTML =
      '<div style="padding:16px;font-family:system-ui;">' +
      '<h2 style="color:#b00020;">找不到必要的 HTML id</h2>' +
      "<p>請確認 HTML 裡有這些 id：<b>" + missing.join(", ") + "</b></p>" +
      "</div>";
    return;
  }

  // ====== STATE ======
  var stage = 1;
  var index = 0;
  var locked = false;

  // main 錯題紀錄（用來挑 review 題）
  var wrongSet = {};

  // 模式：main / review
  var mode = "main";

  // review 題目隊列（放 words 的 index）
  var reviewQueue = [];
  var reviewPos = 0;

  // 用來判斷「是否已經一輪都答對」
  var reviewAddedThisRound = false;

  // ====== STAGE TITLE ======
  var stageTitle = document.createElement("div");
  stageTitle.style.margin = "10px 0";
  stageTitle.style.fontWeight = "800";
  stageTitle.style.color = "#2f6fed";
  wordEl.parentNode.insertBefore(stageTitle, wordEl);

  // ====== START ======
  startBtn.onclick = function () {
    startBtn.style.display = "none";
    game.style.display = "block";

    // reset
    stage = 1;
    index = 0;
    locked = false;
    wrongSet = {};
    mode = "main";
    reviewQueue = [];
    reviewPos = 0;
    reviewAddedThisRound = false;

    render();
  };

  // ====== RENDER ======
  function render() {
    locked = false;
    feedback.innerHTML = "";
    nextBtn.style.display = "none";
    choicesEl.innerHTML = "";

    if (mode === "review") {
      // progress for review
      if (progressBar) {
        progressBar.max = reviewQueue.length;
        progressBar.value = reviewPos;
      }

      // ✅ 完成條件：走到隊尾，且這一輪沒有新增「被丟到隊尾」的題
      if (reviewPos >= reviewQueue.length) {
        if (reviewAddedThisRound) {
          // 代表本輪有人答錯被丟到尾巴 → 再跑一輪
          reviewPos = 0;
          reviewAddedThisRound = false;
        } else {
          // 代表整輪全對 → 完成
          stageTitle.textContent = "";
          wordEl.textContent = "🏁 錯題本通關！";
          defEl.textContent = "太棒了！你已把錯題本全部答對，正式通關。";
          return;
        }
      }

      // show review question
      var wIndex = reviewQueue[reviewPos];
      var currentR = words[wIndex];

      stageTitle.textContent = "錯題本重練（必須全對） " + (reviewPos + 1) + "/" + reviewQueue.length;
      wordEl.textContent = currentR.word;

      // ✅ 答題前不洩漏答案
      defEl.textContent = "提示：先排除明顯不合理的選項。";

      var optionsR = buildOptions(currentR.def);
      for (var i = 0; i < optionsR.length; i++) {
        (function (opt) {
          var btn = document.createElement("button");
          btn.textContent = opt;
          btn.className = "choice";
          btn.onclick = function () {
            checkAnswer(opt, currentR.def, btn, wIndex);
          };
          choicesEl.appendChild(btn);
        })(optionsR[i]);
      }

      nextBtn.textContent = "下一題";
      return;
    }

    // ====== MAIN MODE ======
    if (progressBar) {
      progressBar.max = words.length;
      progressBar.value = index;
    }

    var start = (stage - 1) * STAGE_SIZE;
    var end = start + STAGE_SIZE;

    // 全部做完 → 進錯題本
    if (index >= words.length) {
      prepareReview();
      return;
    }

    // 每關完成畫面
    if (index >= end) {
      stageTitle.textContent = "第 " + stage + " 關（完成）";
      wordEl.textContent = "✅ 第 " + stage + " 關完成！";
      defEl.textContent = "按「下一題」進入下一關。";
      nextBtn.textContent = "下一關";
      nextBtn.style.display = "inline-block";
      return;
    }

    // 正常題
    var withinStage = (index - start) + 1;
    stageTitle.textContent = "第 " + stage + " 關（" + withinStage + "/10）";

    var current = words[index];
    wordEl.textContent = current.word;

    // ✅ 答題前不洩漏
    defEl.textContent = "提示：先排除明顯不合理的選項。";

    var options = buildOptions(current.def);
    for (var j = 0; j < options.length; j++) {
      (function (opt2) {
        var btn2 = document.createElement("button");
        btn2.textContent = opt2;
        btn2.className = "choice";
        btn2.onclick = function () {
          checkAnswer(opt2, current.def, btn2, index);
        };
        choicesEl.appendChild(btn2);
      })(options[j]);
    }

    nextBtn.textContent = "下一題";
  }

  // ====== PREPARE REVIEW ======
  function prepareReview() {
    var wrongList = [];
    for (var key in wrongSet) {
      if (wrongSet.hasOwnProperty(key)) wrongList.push(parseInt(key, 10));
    }

    if (wrongList.length === 0) {
      stageTitle.textContent = "";
      wordEl.textContent = "🎉 全部完成！";
      defEl.textContent = "太棒了！你 20 題全對，沒有錯題需要重練。";
      return;
    }

    reviewQueue = shuffle(wrongList.slice()).slice(0, REVIEW_LIMIT);
    reviewPos = 0;
    reviewAddedThisRound = false;
    mode = "review";

    stageTitle.textContent = "錯題本準備中…";
    wordEl.textContent = "📌 進入錯題本重練（必須全對）";
    defEl.textContent = "規則：答錯的題目會被丟到隊尾，直到你把整個錯題隊伍全部答對才算通關。按「下一題」開始。";
    nextBtn.textContent = "開始重練";
    nextBtn.style.display = "inline-block";
  }

  // ====== OPTIONS ======
  function buildOptions(correctDef) {
    var distractorPool = [
      "a kind of food",
      "a place to sleep",
      "a person who teaches students",
      "a time after dinner",
      "something you wear on your head",
      "a tool used to cut paper"
    ];

    var distractors = shuffle(distractorPool.slice());
    var pick = [];
    for (var i = 0; i < distractors.length && pick.length < 2; i++) {
      if (distractors[i] !== correctDef) pick.push(distractors[i]);
    }

    var all = [correctDef, pick[0], pick[1]];
    return shuffle(all);
  }

  // ====== CHECK ANSWER ======
  function checkAnswer(selected, correct, btn, wIndex) {
    if (locked) return;
    locked = true;

    var current = words[wIndex];

    var btns = choicesEl.querySelectorAll("button");
    for (var i = 0; i < btns.length; i++) {
      btns[i].disabled = true;
    }

    if (selected === correct) {
      // ✅ 答對：不洩漏答案
      btn.classList.add("correct");
      feedback.innerHTML = "✅ <b>答對了！</b><br>做得好！下一題繼續。";
    } else {
      btn.classList.add("wrong");

      // main：記錄錯題
      if (mode === "main") {
        if (!wrongSet[wIndex]) wrongSet[wIndex] = true;
      }

      // review：答錯丟到隊尾（關鍵）
      if (mode === "review") {
        reviewQueue.push(wIndex);
        reviewAddedThisRound = true;
      }

      // ❌ 答錯：顯示答案 + 中文解析
      feedback.innerHTML =
        "❌ <b>答錯沒關係！</b><br>" +
        "✅ 正確答案（英文解釋）：<b>" + correct + "</b><br>" +
        "中文解析：" + current.zhExplain + "<br>" +
        "易混字提醒：<b>" + current.confusable + "</b><br>" +
        (mode === "review" ? "<br>📌 這題已丟到隊尾，稍後會再出現一次。" : "");
    }

    nextBtn.style.display = "inline-block";
    nextBtn.textContent = "下一題";
  }

  // ====== NEXT ======
  nextBtn.onclick = function () {
    if (mode === "review") {
      reviewPos = reviewPos + 1;
      render();
      return;
    }

    var start = (stage - 1) * STAGE_SIZE;
    var end = start + STAGE_SIZE;

    if (index >= end) {
      stage = stage + 1;
      render();
      return;
    }

    index = index + 1;
    render();
  };

  // ====== SHUFFLE ======
  function shuffle(arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
    }
    return arr;
  }
});
