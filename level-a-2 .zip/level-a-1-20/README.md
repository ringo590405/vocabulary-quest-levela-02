# 高中英文Level A 第 1 包（20）

A Pen created on CodePen.

Original URL: [https://codepen.io/qenuinjk-the-decoder/pen/zxBYPej](https://codepen.io/qenuinjk-the-decoder/pen/zxBYPej).

